<script>
	let darkMode = localStorage.getItem("darkMode") === "true";

	function toggleTheme() {
		darkMode = !darkMode;
		localStorage.setItem("darkMode", darkMode);
		updateTheme();
	}

	function updateTheme() {
		if (darkMode) {
			document.documentElement.style.setProperty("--bg-color", "#000000");
			document.documentElement.style.setProperty(
				"--bg-color-hover",
				"#ffffff11"
			);
			document.documentElement.style.setProperty("--text-color", "#d1d1d1");
			document.documentElement.style.setProperty(
				"--text-color-hover",
				"#ffffff"
			);
			document.documentElement.style.setProperty("--text-color-dim", "#808080");
			document.documentElement.style.setProperty("--border-color", "#ffffff22");
			document.documentElement.style.setProperty(
				"--border-color-hover",
				"#ffffff66"
			);
			document.documentElement.style.setProperty(
				"--search-bg-color:",
				"#ffffff11"
			);
		} else {
			document.documentElement.style.setProperty("--bg-color", "#ffffff");
			document.documentElement.style.setProperty(
				"--bg-color-hover",
				"#00000011"
			);
			document.documentElement.style.setProperty("--text-color", "#000000");
			document.documentElement.style.setProperty(
				"--text-color-hover",
				"#000000"
			);
			document.documentElement.style.setProperty("--text-color-dim", "#606060");
			document.documentElement.style.setProperty("--border-color", "#00000022");
			document.documentElement.style.setProperty(
				"--border-color-hover",
				"#00000066"
			);
			document.documentElement.style.setProperty(
				"--search-bg-color:",
				"#00000044"
			);
		}
	}

	import { onMount } from "svelte";
	onMount(() => {
		updateTheme();
	});
</script>

<div class="menu">
	<button class="toggle-btn" on:click={toggleTheme}>
		<span>
			{#if darkMode}
				🌙
			{:else}
				🌞
			{/if}
		</span>
	</button>
</div>

<style>
	.menu {
		position: fixed;
		bottom: 16px;
		right: 16px;
		z-index: 1000;
	}

	.toggle-btn {
		background-color: var(--bg-color);
		color: var(--text-color);
		border-radius: var(--border-radius);
		border: none;
		padding: var(--padding);
		cursor: pointer;
		font-size: var(--font-size);
		
		transition:
			background-color 0.3s var(--animation-curve),
			color 0.3s var(--animation-curve);
	}

	.toggle-btn:hover {
		background-color: var(--bg-color-hover);
		color: var(--text-color-hover);
	}

	button span {
		filter:grayscale(1) contrast(0);
		opacity:0.5;
	}
</style>
